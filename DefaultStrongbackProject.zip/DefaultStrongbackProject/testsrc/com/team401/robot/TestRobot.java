/* Created Mon Nov 21 19:15:56 EST 2016 */
package com.team401.robot;

import org.junit.Test;

public class TestRobot {

    @Test
    public void test() {
        // do something here
    }

}
